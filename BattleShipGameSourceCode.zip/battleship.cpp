#include "battleship.h"
#include <cstdlib>
#include <cmath>
using namespace std;

/*-------------------------------------
FUNCTION NAME: intToStr
PARAMETER(S): int x
RETURN TYPE: string
POSTCONDITION(S): returns int as string
-------------------------------------*/

string intToStr(int x)
{
  int digits = int(log10(x)) + 1;
  string str;
  
  if (x == 0)
    return "0";

  for (int i = 0; i < digits; i++)
    {
      char digit = (x % 10) + '0';
      str = digit + str;
      x = x / 10;
    }
  return str;
}

/*---------------------------------------
Constructor
PARAMETER(S): ifstream& in
POSTCONDITION(S):creates battleship object
---------------------------------------*/
battleship::battleship(ifstream& in)
{

  char ch;
  
  for (int i = 0; i < ROWS; i++)
    {
    for (int j = 0; j < COLUMNS; j++)
      {
	playerGrid[i][j] = ' ';
	in >> ch;
	if (ch == '1')
	  solutionGrid[i][j] = true;
	else
	  solutionGrid[i][j] = false;
      }
    }
  maxMoves = 20;
  movesMade = 0;
}
/*---------------------------------------
FUNCTION NAME: Fire
PARAMETER(S): char x, int y
RETURN TYPE: char
POSTCONDITION(S): increments movesMade and 
places 'X' in player chosen coordinates if
true; '-' if false
---------------------------------------*/
char battleship::fire(char x, int y)
{
  char H, M, X;

  int ix;

  ix = x - 'A';
  y = y - 1;
  
  movesMade++;

  if (solutionGrid[ix][y] == true)
    {
      playerGrid[ix][y] = 'X';
      return 'H';
    }
  
  else if (solutionGrid[ix][y] == false)
    {
      playerGrid[ix][y] = '-';
      return 'M';
    }
}
/*---------------------------------------
FUNCTION NAME: isOver
PARAMETER(S): N/A
RETURN TYPE: char
POSTCONDITION(S): will return C if player
has not chosen all true positions and there
are moves remaining. return L if no moves
remaining and player has not hit all true
positions. retuns W at any other condition(s)
---------------------------------------*/
char battleship::isOver() const
{
  char L, W, C;

  for (int i = 0; i < ROWS; i++)
    {
      for (int j = 0; j < COLUMNS; j++)
	{
	  if ((solutionGrid[i][j] == true) && (playerGrid[i][j] != 'X'))
	    {
	      if (remaining() > 0)
	      return 'C';
	      else if (remaining() == 0)
	      return 'L';
	    }
	}
    }

       return 'W';

}
/*---------------------------------------
FUNCTION NAME: getGrid
PARAMETER(S): N/A
RETURN TYPE: string
POSTCONDITION(S): returns playergrid as
a string with rows and columns labeled
---------------------------------------*/
string battleship::getGrid() const
{
  string s = "";
  
  for (int i = 0; i < ROWS; i++)
    {
      s = s + " " + intToStr(i+1);
    }

  s = s + '\n';
  
  for (int i = 0; i < ROWS; i++)
    {
      char l = 'A' + i;
      s = s + l + '|';
      for (int j = 0; j < COLUMNS; j++)
	{
	  s = s + playerGrid[i][j] + '|';
	}
      s = s + '\n';
    }

  return s;
}
/*---------------------------------------
FUNCTION NAME:remaining
PARAMETER(S): N/A
RETURN TYPE: int
POSTCONDITION(S): counts how many moves remaining
---------------------------------------*/
int battleship::remaining() const
{
  int remaining;

  remaining = maxMoves - movesMade;

  return remaining;
  
}


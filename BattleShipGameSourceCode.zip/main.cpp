#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctype.h>
#include "battleship.h"
using namespace std;

int main()
{
  ifstream in;
  string infilename;
  char x, fire, outcome, X;
  int y;

  cout << "Enter the filename for board initialization: ";
  cin >> infilename; //reads in input file name
  cout << endl;

  while (cin)//while loop that reprompts user for inputfile if file does not exist
{
  in.open(infilename.c_str());//opens input file
  
  if (!in)
    {
      cout << "File not found. Please try again." << endl << endl;
      
      cout << "Enter the filename for board initialization: ";
      cin >> infilename;
      cout << endl;
    }

  else
    break;

 }
    
  battleship game(in);//creates object

  cout << "Enter firing coordinates: ";//prompts user for input
  cin >> x;
  X = toupper(x);//changes lowercase input to uppercase
  
  cin >> y;
  while (cin)
    {
      if ((X >= 'A') && (X <= 'J') && (y >= 1) && (y <= 10))//keeps player moves within bounds of array
	{
	break;  
	}
      else
	{
	cout << "Incorrect Entry, Please Try Again." << endl << endl;
	cin >> x;
	X = toupper(x);
	cin >> y;
	}
		
    }


  while (game.isOver() == 'C') //while loop to run game
{

  fire = game.fire(X,y);//class fire function

  if (fire == 'H')
    cout << endl << "Hit!" << endl;

  else if (fire == 'M')
    cout << endl << "Miss!" << endl;

  cout << endl <<  "Current Game Status:" << endl;
  cout << game.getGrid() << endl << endl;//prints player grid

  cout << "Ammo Remaining: " << game.remaining() << endl << endl;

  outcome = game.isOver();//determines if game is over or continues

    if (outcome == 'L')
       {
	 cout << endl <<  "YOU LOSE, plez don't cry TA." << endl;
	 return 0;
       }
  if (outcome == 'W')
       {
	 cout << endl << "YOU WIN, TA!" << endl;
	 return 0;
       }

  cout << "Enter firing coordinates: ";
  cin >> x;
  X = toupper(x);

  cin >> y;
  
  while (cin)
  if ((X >= 'A') && (X <= 'J') && (y >= 1) && (y <= 10))//keeps player moves within bounds of array
    {
      break;
    }
  else
    {
      cout << "Incorrect Entry, Please Try Again." << endl << endl;
      cin >> x;
      X = toupper(x);
      cin >> y;
    }

 }

  return 0;
  
  
}



//Thanks For Playing!
